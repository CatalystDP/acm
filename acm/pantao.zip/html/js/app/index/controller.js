/**
 * Created by dp on 14-2-11.
 */
define(function(require,exports,module){
    var $dm=dm,$=jQuery,
        body=$("body");
    var view=require("./view");view.init(body);
    var model=require("./model");model.init(body);
    //your code goes here
});